# YM_Project

.env file is in the drive folder copy the .env file to the root directory of the project
